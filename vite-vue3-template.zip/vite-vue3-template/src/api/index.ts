import * as login from './module/login'
import * as index from './module/index'

export default Object.assign({}, login, index)
